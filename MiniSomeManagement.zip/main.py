name = input('type a name: ')
adj1 = input('type an adjective: ')
adj2 = input('type an adjective: ')
adv = input('type an adverb: ')
food = input('type a food: ')
food2 = input('type another food: ')
noun = input('type a noun: ')
pla = input('type a place: ')
verb = input('type a verb: ')




print(f'{name} was planning a dream vacation to {pla}. {name} was especially looking forward to trying the local cuisine, including {adj1} {food} and {food2}. {name} will have to practice the language {adv} to make it easier to {verb} with people. {name} has a long list of sights to see, including the {noun} museum and the {adj2} park.' )